﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace pTesteMatriz
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar;
                for (var i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox(
                    $"Digite o {i+1}º número:", 
                    "Entrada de dados");
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número Inválido.");
                    i--;
                }
            }
                Array.Reverse(vetor);
            auxiliar = "";
            foreach (int i in vetor)
            {
                auxiliar += i + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            ArrayList nomes = new ArrayList();
            nomes.Add("Ana");
            nomes.Add("André");
            nomes.Add("Débora");
            nomes.Add("Fátima");
            nomes.Add("João");
            nomes.Add("Janete");
            nomes.Add("Otávio");
            nomes.Add("Marcelo");
            nomes.Add("Pedro");
            nomes.Add("Thais");
            nomes.RemoveAt(6);

            string auxiliar = "";
            foreach (string i in nomes)
            {
                auxiliar += i + "\n";
            }
            MessageBox.Show(auxiliar);



        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string auxiliar;
            for (var i = 0; i < 20; i++)
            {
                for (int j = 0; i < 3; j++) ;
                {
                    auxiliar = Interaction.InputBox($"Digite a {i + 1}ª nota.");
                }

            }
        }
    }
}
