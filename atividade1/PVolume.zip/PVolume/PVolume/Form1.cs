﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double VlrRaio, VlrAltura;
            if ((!double.TryParse(txtRaio.Text, out VlrRaio) || !double.TryParse(txtAltura.Text, out VlrAltura))) { MessageBox.Show("Algum valor digitado é invalido"); }
            else if (VlrRaio <= 0 || VlrAltura <= 0) { MessageBox.Show("Algum Valor Abaixo de zero"); txtRaio.Focus(); }
            else
            {
                double Volume;
                Volume = Math.PI * Math.Pow(VlrRaio, 2) * VlrAltura;
                txtVolume.Text = Volume.ToString("N2");
                Console.Beep();
            }
         

        
        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            double VlrRaio;
            if (!double.TryParse(txtRaio.Text, out VlrRaio)) { MessageBox.Show("Digite um Raio Valido"); }
            else if (VlrRaio <= 0) { MessageBox.Show("Digite um valor positivo para o raio maior que 0"); }
        }

        private void txtAltura_TextChanged(object sender, EventArgs e)
        {
            double VlrAltura;
            if (!double.TryParse(txtAltura.Text, out VlrAltura)) { MessageBox.Show("Digite uma altura valida"); }
            else if (VlrAltura <= 0) { MessageBox.Show("Digite um valor positivo para a altura que seja maior que zero"); }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
