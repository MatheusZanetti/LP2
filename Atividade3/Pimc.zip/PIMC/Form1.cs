﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMC
{
    public partial class Form1 : Form
    {

        double IMC, Peso, Altura;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxAltura.Text = string.Empty;
            mskbxPeso.Text = string.Empty;
            txtIMC.Text = string.Empty;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnIMC_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxPeso.Text, out Peso) || !double.TryParse(mskbxAltura.Text, out Altura))
            {
                MessageBox.Show("Digite algum valor valido");
                mskbxPeso.Focus();
            }
            else
            {
                if (Altura <= 0 || Peso <= 0)
                {
                    MessageBox.Show("Digite uma valor maior que zero");

                }
                else
                {
                    IMC = Peso / Math.Pow(Altura, 2);
                    IMC = Math.Round(IMC);
                    if (IMC < 18.5)
                    {
                        MessageBox.Show("IMC = {} Magreza e Grau de obsedidae 0", "IMC");
                    }
                    else if (IMC < 24.9 && IMC > 18.5)
                    {
                        MessageBox.Show("IMC = {} normal e Grau de obsedidae 0", "IMC");
                    }
                    else if (IMC > 24.9 && IMC < 29.9)
                    {
                        MessageBox.Show("IMC = {} Sobrepeso e Grau de obsedidae 1", "IMC");
                    }
                    else if (IMC > 29.9 && IMC < 39.9)
                    {
                        MessageBox.Show("IMC = {} Obesidade e Grau de obsedidae 2", "IMC");
                    }
                    else
                    {
                        MessageBox.Show("IMC = {} Obesidade  Grave e Grau de obsedidae 3", "IMC");
                    }
                }


            }


        }
    }
}
