﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace PClasses
{
    abstract internal class Empregado
    {
      
 
        private int matricula;
        private string nomeEmpregrado;
        private DateTime dataEntradaempresa;

        public int Matricula
        {
            get { return matricula; }
            set { matricula = value; }
        }
        public string NomeEmpregrado
        {
            get { return nomeEmpregrado; }
            set { nomeEmpregrado = value; }
        }
        public DateTime DataEntradaEmpresa
        {
            get { return dataEntradaempresa; }
            set { dataEntradaempresa = value; }
        }
        //métodos são ações/compartamentos (virtual permite sobreescrever a função)
        public virtual int TempoTrabalho()
        {
            TimeSpan span = DateTime.Today.Subtract(DataEntradaEmpresa);
            return (span.Days);
        }
        //Tem que ser implementada
        public abstract double SalarioBruto();

        public Empregado() 
        {
            System.Windows.Forms.MessageBox.Show("Aqui foi construido um empregado");
        }
        public Empregado(int mat, string nome, DateTime datax)
        {
            matricula = mat;
            nomeEmpregrado = nome;
            dataEntradaempresa= datax;
        }
        ~Empregado() 
        {
            System.Windows.Forms.MessageBox.Show("Aqui foi destruido um empregado");        
        }
    }
}
