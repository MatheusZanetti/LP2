﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace PClasses
{
    internal class Mensalista : Empregado
    {
        public double SalarioMensal{ get; set; }

        public override double SalarioBruto()
        {
            return SalarioMensal;
        }


        public Mensalista()
        {
            System.Windows.Forms.MessageBox.Show("Aqui foi construido um Mensalista");
        }  
        public Mensalista(int matx, string nomex, DateTime datax, double salx)
        {
            this.NomeEmpregrado = nomex;
            this.Matricula = matx;
            this.DataEntradaEmpresa = datax;
            this.SalarioMensal = salx;
        }

        public static String Empresa = "Toyota Moura";
        public const String Filial = "Filial Sorocaba do moura";

        ~Mensalista()
        {
            System.Windows.Forms.MessageBox.Show("Aqui foi destruido um Mensalista");
        }

    }
}
