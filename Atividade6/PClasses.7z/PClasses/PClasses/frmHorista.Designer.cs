﻿namespace PClasses
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNumHoras = new System.Windows.Forms.Label();
            this.lblSalarioHoras = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblMatricula = new System.Windows.Forms.Label();
            this.txtHoras = new System.Windows.Forms.TextBox();
            this.txtSalarioHoras = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.btnInstHorario = new System.Windows.Forms.Button();
            this.lblDiasFalta = new System.Windows.Forms.Label();
            this.txtFaltas = new System.Windows.Forms.TextBox();
            this.lblData = new System.Windows.Forms.Label();
            this.txtData = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblNumHoras
            // 
            this.lblNumHoras.AutoSize = true;
            this.lblNumHoras.Location = new System.Drawing.Point(147, 169);
            this.lblNumHoras.Name = "lblNumHoras";
            this.lblNumHoras.Size = new System.Drawing.Size(88, 13);
            this.lblNumHoras.TabIndex = 19;
            this.lblNumHoras.Text = "Número de horas";
            // 
            // lblSalarioHoras
            // 
            this.lblSalarioHoras.AutoSize = true;
            this.lblSalarioHoras.Location = new System.Drawing.Point(147, 132);
            this.lblSalarioHoras.Name = "lblSalarioHoras";
            this.lblSalarioHoras.Size = new System.Drawing.Size(81, 13);
            this.lblSalarioHoras.TabIndex = 18;
            this.lblSalarioHoras.Text = "Salário por hora";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(166, 92);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(35, 13);
            this.lblNome.TabIndex = 17;
            this.lblNome.Text = "Nome";
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Location = new System.Drawing.Point(164, 46);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(52, 13);
            this.lblMatricula.TabIndex = 16;
            this.lblMatricula.Text = "Matrícula";
            // 
            // txtHoras
            // 
            this.txtHoras.Location = new System.Drawing.Point(287, 166);
            this.txtHoras.Name = "txtHoras";
            this.txtHoras.Size = new System.Drawing.Size(125, 20);
            this.txtHoras.TabIndex = 15;
            // 
            // txtSalarioHoras
            // 
            this.txtSalarioHoras.Location = new System.Drawing.Point(287, 125);
            this.txtSalarioHoras.Name = "txtSalarioHoras";
            this.txtSalarioHoras.Size = new System.Drawing.Size(125, 20);
            this.txtSalarioHoras.TabIndex = 14;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(287, 85);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(380, 20);
            this.txtNome.TabIndex = 13;
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(287, 43);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(76, 20);
            this.txtMatricula.TabIndex = 12;
            // 
            // btnInstHorario
            // 
            this.btnInstHorario.Location = new System.Drawing.Point(264, 302);
            this.btnInstHorario.Name = "btnInstHorario";
            this.btnInstHorario.Size = new System.Drawing.Size(197, 106);
            this.btnInstHorario.TabIndex = 10;
            this.btnInstHorario.Text = "Instanciar Horista";
            this.btnInstHorario.UseVisualStyleBackColor = true;
            this.btnInstHorario.Click += new System.EventHandler(this.btnInstHorario_Click);
            // 
            // lblDiasFalta
            // 
            this.lblDiasFalta.AutoSize = true;
            this.lblDiasFalta.Location = new System.Drawing.Point(164, 210);
            this.lblDiasFalta.Name = "lblDiasFalta";
            this.lblDiasFalta.Size = new System.Drawing.Size(54, 13);
            this.lblDiasFalta.TabIndex = 21;
            this.lblDiasFalta.Text = "Dias Falta";
            // 
            // txtFaltas
            // 
            this.txtFaltas.Location = new System.Drawing.Point(287, 207);
            this.txtFaltas.Name = "txtFaltas";
            this.txtFaltas.Size = new System.Drawing.Size(125, 20);
            this.txtFaltas.TabIndex = 20;
            // 
            // lblData
            // 
            this.lblData.AutoSize = true;
            this.lblData.Location = new System.Drawing.Point(127, 258);
            this.lblData.Name = "lblData";
            this.lblData.Size = new System.Drawing.Size(129, 13);
            this.lblData.TabIndex = 23;
            this.lblData.Text = "Data Entrada na Empresa";
            // 
            // txtData
            // 
            this.txtData.Location = new System.Drawing.Point(287, 255);
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(125, 20);
            this.txtData.TabIndex = 22;
            // 
            // frmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblData);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.lblDiasFalta);
            this.Controls.Add(this.txtFaltas);
            this.Controls.Add(this.lblNumHoras);
            this.Controls.Add(this.lblSalarioHoras);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblMatricula);
            this.Controls.Add(this.txtHoras);
            this.Controls.Add(this.txtSalarioHoras);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.btnInstHorario);
            this.Name = "frmHorista";
            this.Text = "frmHorista";
            this.Load += new System.EventHandler(this.frmHorista_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNumHoras;
        private System.Windows.Forms.Label lblSalarioHoras;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.TextBox txtHoras;
        private System.Windows.Forms.TextBox txtSalarioHoras;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.Button btnInstHorario;
        private System.Windows.Forms.Label lblDiasFalta;
        private System.Windows.Forms.TextBox txtFaltas;
        private System.Windows.Forms.Label lblData;
        private System.Windows.Forms.TextBox txtData;
    }
}