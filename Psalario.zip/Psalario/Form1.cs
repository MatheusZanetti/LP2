﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Form1 : Form
    {

        double SalBruto, DescINSS,DescIRPF,SalFamilia,SalLiquid, NumFilhos;
 
        public Form1()
        {
            InitializeComponent();
         
        }
       

        private void txtNomeFunc_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(char.IsNumber(e.KeyChar) || char.IsPunctuation(e.KeyChar))
            {
                MessageBox.Show("Character invalido");
                SendKeys.Send("{backspace}");
            }
        }

        private void btnVerificarDescoato_Click(object sender, EventArgs e)
        {
         if(!double.TryParse(mskbxSalBruto.Text, out SalBruto))
            {
                MessageBox.Show("Digite algum valor valido");
                mskbxSalBruto.Focus();
            }
            if (SalBruto <= 800.47)
            {
                txtINSS.Text = "7,65%";
                DescINSS = 0.0765 * SalBruto;
                txtDescontoINSS.Text = $"{DescINSS}";
            }
            else if (SalBruto <= 1050)
            {
                txtINSS.Text = "8,65%";
                DescINSS = (8.65 / 100) * SalBruto;
                txtDescontoINSS.Text = $"{DescINSS}";
            }
            else if (SalBruto <= 1400.77)
            {
                txtINSS.Text = "9%";
                DescINSS = (9 / 100) * SalBruto;
                txtDescontoINSS.Text = $"{DescINSS}";
            }
            else if (SalBruto <= 2801.56)
            {
                txtINSS.Text = "11%";
                DescINSS = (11/ 100) * SalBruto;
                txtDescontoINSS.Text = $"{DescINSS}";
            }
            else if (SalBruto > 2801.56)
            {
                txtINSS.Text = "Teto o valor é 308.17";
                DescINSS = 308.17;
                txtDescontoINSS.Text = $"{DescINSS}";
            }
            if(SalBruto <= 1257.12)
            {
                txtIRPF.Text = "Isento";
                DescIRPF = 0;
                txtDescontoIRPF.Text = "0";
            }
            if (SalBruto <= 1257.12)
            {
                txtIRPF.Text = "Isento";
                DescIRPF = 0;
                txtDescontoIRPF.Text = "0";
            }
            else if (SalBruto <= 2512.08)
            {
                txtIRPF.Text = "15%";
                DescIRPF = (15 /100) * SalBruto;
                txtDescontoIRPF.Text = $"{DescIRPF}";
            }
            else if (SalBruto > 2512.08)
            {
                txtIRPF.Text = "27.5%";
                DescIRPF =(27.5/100) * SalBruto;
                txtDescontoIRPF.Text = $"{DescIRPF}";
            }
            if (SalBruto <= 435.52)
            {
                txtSalFamilia.Text = "22.33";
                NumFilhos = Convert.ToDouble(NupFilhos.Value);
                SalFamilia = 22.33 * NumFilhos;
            }
            else if (SalBruto <= 654.61)
            {
                txtSalFamilia.Text = "15.74";
                NumFilhos = Convert.ToDouble(NupFilhos.Value);
                SalFamilia = 15.74 * NumFilhos;
            }
            else if (SalBruto <= 654.61)
            {
                txtSalFamilia.Text = "0";
            }
            }

        }
}
/// 700.47 (7,65)
/// (1050)