﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalc
{
    public partial class Form1 : Form
    {
        double I1, I2;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            this. I1 = double.Parse(txtNum1.Text);
            this. I2 = double.Parse(txtNum2.Text);
            txtResult.Text = Convert.ToString(I1 * I2);
         
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            this. I1 = double.Parse(txtNum1.Text);
            this. I2 = double.Parse(txtNum2.Text);
            if (I1 == 0 || I2 == 0)
            {
                MessageBox.Show("Zero é invalido na divisão");
                txtNum1.Text = txtNum1.Text.Replace(txtNum1.Text, "");
                txtNum2.Text = txtNum2.Text.Replace(txtNum2.Text, "");
            }
            else { txtResult.Text = Convert.ToString(I1 / I2); }

        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            this.I1 = double.Parse(txtNum1.Text);
            this.I2 = double.Parse(txtNum2.Text);
            txtResult.Text = Convert.ToString(I1 - I2);
         
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
  
            

         

            this.I1 = double.Parse(txtNum1.Text);
            this.I2 = double.Parse(txtNum2.Text);
            txtResult.Text = Convert.ToString(I1+I2);
        
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Text = txtNum1.Text.Replace(txtNum1.Text, "1");
            txtNum2.Text = txtNum2.Text.Replace(txtNum2.Text, "1");
            txtResult.Text = txtResult.Text.Replace(txtResult.Text, "");
        }

        private void txtNum2_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNum2_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtNum1.Text = "1";
            txtNum1.MaxLength = 9;
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.') && (e.KeyChar != '-'))
            {
                e.Handled = true;
            }
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
            if ((e.KeyChar == '-') && ((sender as TextBox).Text.IndexOf('-') > -1))
            {
                e.Handled = true;
            }
        }

        private void txtNum1_Click(object sender, EventArgs e)
        {

        }

        private void txtNum1_KeyPress(object sender, KeyPressEventArgs e)
        {
            txtNum1.Text = "1";
            txtNum1.MaxLength = 9;
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.') && (e.KeyChar != '-'))
            {
                e.Handled = true;
            }
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
            if ((e.KeyChar == '-') && ((sender as TextBox).Text.IndexOf('-') > -1))
            {
                e.Handled = true;
            }

        }
    }
}
